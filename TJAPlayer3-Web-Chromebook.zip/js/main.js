import { Renderer } from './core/renderer.js';
import { Clock } from './core/clock.js';
import { Input } from './core/input.js';
import { Settings, loadSettings, saveSettings, Users } from './core/settings.js';
import { AudioManager } from './core/audio.js';
import { SOUNDS } from './core/sounds.js';
import { Assets } from './core/assets.js';
import { StartupStage } from './stages/startup.js';
import { TitleStage } from './stages/title.js';
import { ConfigStage } from './stages/config.js';
import { SongLoadingStage } from './stages/loading.js';
import { ResultStage } from './stages/result.js';
import { EndingStage } from './stages/ending.js';
import { ChangeSkinStage } from './stages/changeskin.js';
import { SongSelectStub, DanSelectStub, PlayStub } from './stages/stubs.js';

/** アプリ本体。画面遷移・メインループ・計測を担当する */
class App {
  constructor() {
    this.canvas = document.getElementById('game');
    this.r = new Renderer(this.canvas);
    this.audio = null; this.stages = {}; this.cur = null; this.curName = '';
    this.prev = ''; this.last = 0; this.ft = new Float32Array(240); this.ftI = 0; this.cpu = 0; this.shot = false;
    this.fps = 0; this.low1 = 0; this.showFps = false;
    this.Settings = Settings; this.Users = Users; this.Input = Input;
  }
  register(name, Cls) { this.stages[name] = new Cls(this); }
  go(name, params = {}) {
    if (!this.stages[name]) { console.error('unknown stage', name); return; }
    if (this.cur) this.cur.leave();
    this.prev = this.curName; this.curName = name; this.cur = this.stages[name];
    this.cur.enter(params);
  }
  /** SE を鳴らす（スキンのサウンド id） */
  se(id, o) { return this.audio ? this.audio.play(id, o) : null; }
  applyAudioLevels() { this.audio?.setLevels({ se: Settings.seLevel, voice: Settings.voiceLevel, song: Settings.songLevel }); }
  applyRender() { this.r.resize(Settings.renderWidth || 1920); }

  async loadSounds(onProgress) {
    const root = Assets.root + 'Sounds/'; const ids = Object.keys(SOUNDS); let n = 0;
    await Promise.all(ids.map(async (id) => {
      const [file, group, loop] = SOUNDS[id];
      await this.audio.load(id, root + file, group, !!loop);
      onProgress && onProgress(++n, ids.length);
    }));
  }
  async boot() {
    loadSettings(); Users.load();
    this.showFps = Settings.showFps;
    this.r.resize(Settings.renderWidth || 1920);
    Input.attach(this.canvas, this.r);
    window.addEventListener('resize', () => this.applyRender());
    document.addEventListener('fullscreenchange', () => { Settings.fullscreen = !!document.fullscreenElement; saveSettings(); setTimeout(() => this.applyRender(), 50); });
    this.audio = new AudioManager(); this.applyAudioLevels();
    this.register('startup', StartupStage); this.register('title', TitleStage); this.register('config', ConfigStage);
    this.register('loading', SongLoadingStage); this.register('result', ResultStage); this.register('ending', EndingStage);
    this.register('changeskin', ChangeSkinStage);
    this.register('songselect', SongSelectStub); this.register('danselect', DanSelectStub); this.register('play', PlayStub);
    this.go('startup');
    requestAnimationFrame((t) => { this.last = t; this.loop(t); });
  }
  loop(t) {
    requestAnimationFrame((x) => this.loop(x));
    const cap = Settings.fpsCap;
    if (cap > 0 && t - this.last < 1000 / cap - 1.2) return;
    Clock.dt = Math.min(100, t - this.last); this.last = t; Clock.now = t; Clock.frame++;
    this.ft[this.ftI = (this.ftI + 1) % this.ft.length] = Clock.dt;
    const c0 = performance.now();
    Input.beginFrame();
    if (Input.key('F2')) { this.showFps = !this.showFps; Settings.showFps = this.showFps; saveSettings(); }
    for (const code of (Settings.keys.Capture || [])) if (Input.key(code)) this.shot = true;
    if (this.cur) {
      const res = this.cur.update();
      if (res) this.go(res.to, res.params || {});
    }
    const r = this.r; r.begin(); r.clear('#000');
    if (this.cur) this.cur.draw(r);
    if (this.showFps) this.drawStats(r);
    this.cpu = this.cpu * 0.9 + (performance.now() - c0) * 0.1;
    if (this.shot) { this.shot = false; this.capture(); }
  }
  drawStats(r) {
    let sum = 0, mx = 0; const arr = Array.from(this.ft).filter((v) => v > 0);
    for (const v of arr) { sum += v; if (v > mx) mx = v; }
    const avg = sum / (arr.length || 1); this.fps = 1000 / avg;
    arr.sort((a, b) => b - a); const worst = arr.slice(0, Math.max(1, Math.floor(arr.length * 0.01)));
    this.low1 = 1000 / (worst.reduce((a, b) => a + b, 0) / worst.length);
    r.rect(8, 8, 230, 66, '#000', 0.55);
    const ink = this.fps >= 100 ? '#7CFC00' : this.fps >= 55 ? '#FFE066' : '#FF6B6B';
    r.textRaw(`${this.fps.toFixed(1)} FPS  (1%low ${this.low1.toFixed(0)})`, 16, 12, 18, ink);
    r.textRaw(`frame ${avg.toFixed(2)}ms  cpu ${this.cpu.toFixed(2)}ms`, 16, 34, 14, '#fff');
    r.textRaw(`draw ${r.drawCalls}  ${this.canvas.width}x${this.canvas.height}`, 16, 52, 14, '#ccc');
  }
  capture() {
    this.canvas.toBlob((b) => {
      if (!b) return; const a = document.createElement('a'); const d = new Date(); const p = (n) => String(n).padStart(2, '0');
      a.href = URL.createObjectURL(b); a.download = `TJAPlayer3Web_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.png`;
      a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    }, 'image/png');
  }
  toggleFullscreen(on) {
    if (on && !document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {});
    else if (!on && document.fullscreenElement) document.exitFullscreen?.();
  }
}
const app = new App(); window.app = app;
app.boot().catch((e) => { console.error(e); document.getElementById('err').textContent = String(e && e.stack || e); document.getElementById('err').style.display = 'block'; });
